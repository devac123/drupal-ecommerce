/**
 * @file
 * Global utilities.
 *
 */
(function ($, Drupal) {

  'use strict';

  Drupal.behaviors.sampleTheme = {
    attach: function (context, settings) {

    }
  };

})(jQuery, Drupal);
;
